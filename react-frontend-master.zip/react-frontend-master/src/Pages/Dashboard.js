import ServCard from '../components/Container/ServCard.jsx';
import './Dashboard.scss';

function Dashboard() {
  return (
    <div className='content-container'>
      <p className='main-title'>Dashboard</p>
      <ServCard />
    </div>

  );
}

export default Dashboard;
