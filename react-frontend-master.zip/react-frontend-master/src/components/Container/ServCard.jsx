import { faCheck } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import React, { useState } from 'react';
import './ServCard.scss';

export default function ServCard(props) {

    const [Name] = useState("Default :");

    return (
        <div className="serv-card" id={Name}>

            <div className="card-title-container">

                <p className="card-name">Serv Cool</p>

                <div className="serv-status">
                    <FontAwesomeIcon className='status-icon' icon={faCheck}/>
                    <p>Online</p>
                </div>

            </div>

            <div className="card-properties">
                <div className="left">
                    <p>Users online:</p>
                    <p>Version:</p>
                    <p>Port:</p>
                </div>
                <div className="right">
                    <p>/50</p>
                    <p>pute</p>
                    <p>pute</p>
                </div>
                
            </div>

            <div className="manage-button">
                <p>Manage</p>
            </div>
        </div>
    );

}